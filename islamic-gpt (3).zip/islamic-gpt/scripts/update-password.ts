/**
 * تحديث كلمة مرور الحسابات التجريبية إلى كلمة المرور الجديدة
 * التشغيل: bun run scripts/update-password.ts
 */
import { randomBytes, scryptSync } from "crypto";
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

const NEW_PASSWORD = "islamicgpt333434";

function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `s2$${salt}$${hash}`;
}

async function main() {
  const users = await db.user.findMany({
    where: { email: { in: ["admin@islamicgpt.com", "user@test.com"] } },
    select: { id: true, email: true, role: true },
  });

  for (const u of users) {
    await db.user.update({
      where: { id: u.id },
      data: { passwordHash: hashPassword(NEW_PASSWORD) },
    });
    console.log(`✓ تم تحديث كلمة مرور ${u.role}: ${u.email}`);
  }

  if (users.length === 0) {
    console.error("⚠ لم يتم العثور على الحسابات التجريبية!");
    process.exit(1);
  }
  console.log(`✅ كلمة المرور الجديدة لجميع الحسابات: ${NEW_PASSWORD}`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
