/**
 * حذف مستخدم اختبار مؤقت مع كل بياناته المرتبطة
 * التشغيل: bun run scripts/cleanup-test-user.ts
 */
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

async function main() {
  const email = process.argv[2] || "testfix@islamicgpt.com";
  const u = await db.user.findUnique({ where: { email } });
  if (!u) {
    console.log(`لا يوجد مستخدم: ${email}`);
    return;
  }
  await db.subscriptionRequest.deleteMany({ where: { userId: u.id } });
  await db.subscription.deleteMany({ where: { userId: u.id } });
  await db.chatMessage.deleteMany({ where: { session: { userId: u.id } } });
  await db.chatSession.deleteMany({ where: { userId: u.id } });
  await db.quranProgress.deleteMany({ where: { userId: u.id } });
  await db.user.delete({ where: { id: u.id } });
  console.log(`✓ تم حذف مستخدم الاختبار: ${email}`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
