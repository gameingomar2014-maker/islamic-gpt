/**
 * سكربت البيانات التجريبية والأساسية:
 * 1) زرع نص القرآن الكريم (نسخة عثمانية) من المصدر المنزَّل
 * 2) تنقية قائمة القراء واختيار أشهر الشيخ (٢٧ شيخاً)
 * 3) إنشاء حسابات تجريبية: أدمن + مستخدم + طلب اشتراك
 *
 * التشغيل: bun run scripts/seed.ts
 */
import { readFileSync, writeFileSync, mkdirSync } from "fs";
import { randomBytes, scryptSync } from "crypto";
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

// ---------- أدوات ----------
function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `s2$${salt}$${hash}`;
}

const DIACRITICS = /[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED\u08D3-\u08FF]/g;
function normBasic(s: string): string {
  return s
    .replace(/[\ufeff\u200f\u200e]/g, "")
    .replace(DIACRITICS, "")
    .replace(/[\u0622\u0623\u0625\u0671]/g, "\u0627")
    .replace(/\u0640/g, "");
}

const BISMILLAH_NORM = normBasic("بسم الله الرحمن الرحيم");

/** يزيل البسملة المسبوقة من أول آية (مع الحفاظ على التشكيل الأصلي لما بعدها) */
function stripLeadingBismillah(text: string): string {
  // بناء نسخة مطبّعة مع خريطة مواقع الأحرف الأصلية
  let norm = "";
  const map: number[] = [];
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (/[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED\u08D3-\u08FF]/.test(ch)) continue;
    const mapped = normBasic(ch);
    norm += mapped;
    for (let k = 0; k < mapped.length; k++) map.push(i);
  }
  if (!norm.startsWith(BISMILLAH_NORM)) return text;
  const cutAfter = map[BISMILLAH_NORM.length - 1] + 1;
  return text
    .slice(cutAfter)
    .replace(/^[\s\u00A0\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED\u08D3-\u08FF]+/, "");
}

// ---------- ١) القرآن ----------
async function seedQuran() {
  const raw = JSON.parse(
    readFileSync("/home/z/my-project/data-src/quran-uthmani.json", "utf-8")
  );
  const surahs = raw.data.surahs as Array<{
    number: number;
    name: string;
    englishName: string;
    englishNameTranslation: string;
    revelationType: string;
    ayahs: Array<{ text: string; numberInSurah: number }>;
  }>;

  await db.ayah.deleteMany();
  await db.surah.deleteMany();

  let ayahCount = 0;
  for (const s of surahs) {
    // اسم السورة بدون "سُورَةُ"
    const cleanName = s.name.replace(/^سُورَةُ\s*/, "").trim();
    await db.surah.create({
      data: {
        number: s.number,
        name: cleanName,
        englishName: s.englishName,
        englishTranslation: s.englishNameTranslation,
        revelationType: s.revelationType === "Meccan" ? "مكية" : "مدنية",
        numberOfAyahs: s.ayahs.length,
      },
    });

    const rows = s.ayahs.map((a) => {
      let text = a.text.replace(/[\ufeff\u200f\u200e]/g, "").trim();
      if (s.number !== 1 && s.number !== 9 && a.numberInSurah === 1) {
        text = stripLeadingBismillah(text);
      }
      return { surahNumber: s.number, numberInSurah: a.numberInSurah, text };
    });
    ayahCount += rows.length;
    // إدخال على دفعات
    for (let i = 0; i < rows.length; i += 500) {
      await db.ayah.createMany({ data: rows.slice(i, i + 500) });
    }
  }
  console.log(`✓ القرآن: ${surahs.length} سورة، ${ayahCount} آية`);
}

// ---------- ٢) القراء ----------
type Moshaf = { id: number; name: string; surah_total: number; server: string };
type ApiReciter = { id: number; name: string; moshaf: Moshaf[] };

const FAMOUS = [
  "عبدالباسط عبدالصمد",
  "مشاري العفاسي",
  "ماهر المعيقلي",
  "محمد صديق المنشاوي",
  "محمود خليل الحصري",
  "إدريس أبكر",
  "محمود علي البنا",
  "مصطفى إسماعيل",
  "ماهر شخاشيرو",
  "عادل الكلباني",
  "خالد الجليل",
  "أحمد الحذيفي",
  "هزاع البلوشي",
  "عبدالله الموسى",
  "إسلام صبحي",
  "سعد الغامدي",
  "سعود الشريم",
  "أبو بكر الشاطري",
  "أحمد بن علي العجمي",
  "عبدالرحمن السديس",
  "عبدالله بصفر",
  "عبدالله عواد الجهني",
  "علي جابر",
  "ياسر الدوسري",
  "ناصر القطامي",
  "محمد أيوب",
  "رشيد بلعالية",
];

function curateReciters(): void {
  const raw = JSON.parse(
    readFileSync("/home/z/my-project/data-src/reciters.json", "utf-8")
  );
  const reciters: ApiReciter[] = raw.reciters;

  const chosen: Array<{
    id: number;
    name: string;
    moshaf: string;
    server: string;
  }> = [];

  for (const frag of FAMOUS) {
    const rec = reciters.find((r) => r.name.includes(frag));
    if (!rec) {
      console.warn(`⚠ لم يُعثر على: ${frag}`);
      continue;
    }
    // أفضل مصحف: كامل (١١٤) + مرتل + حفص
    const complete = rec.moshaf.filter((m) => m.surah_total === 114);
    const pick =
      complete.find((m) => m.name.includes("مرتل") && m.name.includes("حفص")) ??
      complete.find((m) => m.name.includes("مرتل")) ??
      complete[0] ??
      rec.moshaf[0];
    if (!pick) continue;
    // تجنب المصحف المعلم للأطفال إن وُجد بديل
    if (pick.name.includes("المعلم") && complete.length > 1) {
      const alt = complete.find((m) => !m.name.includes("المعلم"));
      if (alt) chosen.push({ id: rec.id, name: rec.name, moshaf: alt.name, server: alt.server });
      continue;
    }
    chosen.push({ id: rec.id, name: rec.name, moshaf: pick.name, server: pick.server });
  }

  mkdirSync("/home/z/my-project/src/data", { recursive: true });
  writeFileSync(
    "/home/z/my-project/src/data/reciters.json",
    JSON.stringify(chosen, null, 2),
    "utf-8"
  );
  console.log(`✓ القراء: ${chosen.length} شيخاً (محفوظة في src/data/reciters.json)`);
}

// ---------- ٣) المستخدمين والطلبات التجريبية ----------
async function seedUsers() {
  // تنظيف
  await db.subscriptionRequest.deleteMany();
  await db.subscription.deleteMany();
  await db.chatMessage.deleteMany();
  await db.chatSession.deleteMany();
  await db.quranProgress.deleteMany();
  await db.user.deleteMany();

  const admin = await db.user.create({
    data: {
      email: "admin@islamicgpt.com",
      passwordHash: hashPassword("islamicgpt333434"),
      name: "مدير الموقع",
      role: "ADMIN",
      plan: "WORDS_1500",
      wordBalance: 1500,
    },
  });

  const user = await db.user.create({
    data: {
      email: "user@test.com",
      passwordHash: hashPassword("islamicgpt333434"),
      name: "أحمد التجريبي",
      role: "USER",
      plan: "FREE",
      freeMessagesUsed: 0,
    },
  });

  // طلب اشتراك بانتظار المراجعة (لتجربة لوحة الإدارة)
  await db.subscriptionRequest.create({
    data: {
      userId: user.id,
      planId: "WORDS_500",
      userName: "أحمد التجريبي",
      phone: "01012345678",
      paymentMethod: "vodafone_cash",
      transactionRef: "TX-DEMO-12345",
      status: "PENDING",
      amount: 50,
      words: 500,
    },
  });

  // طلب سابق مقبول (للسجل)
  await db.subscriptionRequest.create({
    data: {
      userId: user.id,
      planId: "WORDS_1500",
      userName: "أحمد التجريبي",
      phone: "01012345678",
      paymentMethod: "instapay",
      transactionRef: "TX-DEMO-99999",
      status: "APPROVED",
      amount: 100,
      words: 1500,
      reviewedAt: new Date(Date.now() - 3 * 24 * 3600 * 1000),
      adminNote: "تم التحقق من التحويل",
    },
  });
  await db.subscription.create({
    data: { userId: user.id, planId: "WORDS_1500", wordsGranted: 0, requestId: null },
  });

  console.log(`✓ المستخدمون: أدمن (${admin.email}) + مستخدم (${user.email})`);
  console.log("✓ طلبات تجريبية: ١ بانتظار المراجعة + ١ مقبول");
}

async function main() {
  console.log("… بدء زرع البيانات");
  await seedQuran();
  curateReciters();
  await seedUsers();
  console.log("✅ اكتملت البيانات التجريبية");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
