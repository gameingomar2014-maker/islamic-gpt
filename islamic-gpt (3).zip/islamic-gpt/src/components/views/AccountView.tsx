"use client";

import { useEffect, useState } from "react";
import { useStore, navigate } from "@/lib/store";
import { FREE_MESSAGES_LIMIT, getPlan, paymentLabel } from "@/lib/plans";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Wallet,
  BadgeCheck,
  Clock3,
  XCircle,
  LogOut,
  CreditCard,
  ShieldCheck,
  Image as ImageIcon,
  User,
} from "lucide-react";

type MyRequest = {
  id: string;
  planId: string;
  amount: number;
  words: number;
  paymentMethod: string;
  transactionRef: string | null;
  status: "PENDING" | "APPROVED" | "REJECTED";
  adminNote: string | null;
  createdAt: string;
  hasReceipt: boolean;
};

const STATUS_META: Record<string, { label: string; icon: React.ElementType; className: string }> = {
  PENDING: { label: "قيد المراجعة", icon: Clock3, className: "bg-amber-50 text-amber-700 border-amber-300" },
  APPROVED: { label: "مقبول", icon: BadgeCheck, className: "bg-emerald-50 text-emerald-700 border-emerald-300" },
  REJECTED: { label: "مرفوض", icon: XCircle, className: "bg-red-50 text-red-700 border-red-300" },
};

export function AccountView() {
  const user = useStore((s) => s.user);
  const authLoading = useStore((s) => s.authLoading);
  const logout = useStore((s) => s.logout);
  const [requests, setRequests] = useState<MyRequest[]>([]);
  const [receiptUrl, setReceiptUrl] = useState<string | null>(null);
  const [receiptOpen, setReceiptOpen] = useState(false);

  useEffect(() => {
    if (!user) return;
    fetch("/api/requests")
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => d && setRequests(d.requests ?? []))
      .catch(() => {});
  }, [user]);

  if (!authLoading && !user) {
    return (
      <div className="max-w-md mx-auto px-4 py-16 text-center">
        <User className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
        <h1 className="text-xl font-extrabold text-islamic-800 mb-2">سجّل الدخول أولاً</h1>
        <p className="text-sm text-muted-foreground mb-6">
          هذه الصفحة تعرض حسابك واشتراكك وحالة طلباتك
        </p>
        <Button className="bg-islamic-800 rounded-full" onClick={() => navigate("/login")}>
          تسجيل الدخول
        </Button>
      </div>
    );
  }

  if (!user) return null;

  const isFree = user.plan === "FREE";
  const plan = getPlan(user.plan);

  const viewReceipt = async (id: string) => {
    try {
      const res = await fetch(`/api/requests/${id}/receipt`);
      if (!res.ok) return;
      const d = await res.json();
      setReceiptUrl(d.receiptImage);
      setReceiptOpen(true);
    } catch {}
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-6 md:py-10">
      <h1 className="text-2xl font-extrabold text-islamic-800 mb-6">حسابي</h1>

      {/* بطاقة الحساب */}
      <Card className="rounded-3xl border-border/70 shadow-sm mb-6">
        <CardContent className="p-6">
          <div className="flex items-center gap-4 mb-5">
            <div className="w-14 h-14 rounded-2xl bg-islamic-800 text-white flex items-center justify-center text-xl font-extrabold">
              {user.name.charAt(0)}
            </div>
            <div className="min-w-0">
              <p className="font-extrabold text-lg text-islamic-900 truncate">{user.name}</p>
              <p className="text-xs text-muted-foreground" dir="ltr">
                {user.email}
              </p>
            </div>
            {user.role === "ADMIN" && (
              <Badge className="mr-auto bg-gold-soft text-islamic-900 gap-1">
                <ShieldCheck className="w-3.5 h-3.5" />
                أدمن
              </Badge>
            )}
          </div>

          <div className="grid sm:grid-cols-2 gap-3">
            <div className="rounded-2xl bg-islamic-50 border border-emerald-200 p-4">
              <div className="flex items-center gap-2 text-xs font-bold text-islamic-700 mb-1">
                <Wallet className="w-4 h-4" />
                الباقة الحالية
              </div>
              <p className="font-extrabold text-islamic-900">
                {isFree ? "المجانية" : plan?.name ?? user.plan}
              </p>
            </div>
            <div className="rounded-2xl bg-islamic-50 border border-emerald-200 p-4">
              <div className="flex items-center gap-2 text-xs font-bold text-islamic-700 mb-1">
                <BadgeCheck className="w-4 h-4" />
                الرصيد المتبقي
              </div>
              <p className="font-extrabold text-islamic-900">
                {isFree
                  ? `${Math.max(0, FREE_MESSAGES_LIMIT - user.freeMessagesUsed)} رسالة من ${FREE_MESSAGES_LIMIT}`
                  : `${user.wordBalance} كلمة`}
              </p>
            </div>
          </div>

          <div className="flex flex-wrap gap-2 mt-5">
            <Button
              onClick={() => navigate("/plans")}
              className="rounded-full bg-islamic-800 hover:bg-islamic-700 gap-2"
            >
              <CreditCard className="w-4 h-4" />
              {isFree ? "ترقية الحساب" : "تجديد / تغيير الباقة"}
            </Button>
            {user.role === "ADMIN" && (
              <Button
                variant="outline"
                className="rounded-full gap-2"
                onClick={() => navigate("/admin")}
              >
                <ShieldCheck className="w-4 h-4" />
                لوحة الإدارة
              </Button>
            )}
            <Button
              variant="outline"
              className="rounded-full gap-2 text-destructive hover:text-destructive"
              onClick={logout}
            >
              <LogOut className="w-4 h-4" />
              تسجيل الخروج
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* الطلبات */}
      <h2 className="text-lg font-extrabold text-islamic-800 mb-3">طلبات الاشتراك</h2>
      {requests.length === 0 ? (
        <Card className="rounded-2xl border-dashed">
          <CardContent className="p-8 text-center text-sm text-muted-foreground">
            لا توجد طلبات بعد — ابدأ بالاشتراك في باقة من صفحة الباقات
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {requests.map((r) => {
            const meta = STATUS_META[r.status] ?? STATUS_META.PENDING;
            const Icon = meta.icon;
            return (
              <Card key={r.id} className="rounded-2xl border-border/70 shadow-sm">
                <CardContent className="p-4 flex flex-wrap items-center gap-3">
                  <div className={`w-10 h-10 rounded-xl border flex items-center justify-center shrink-0 ${meta.className}`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-40">
                    <p className="font-bold text-sm text-islamic-900">
                      {getPlan(r.planId)?.name ?? r.planId} — {r.amount} جنيه
                    </p>
                    <p className="text-xs text-muted-foreground leading-5">
                      {paymentLabel(r.paymentMethod)}
                      {r.transactionRef ? ` • عملية: ${r.transactionRef}` : ""}
                      {r.hasReceipt ? " • مرفق إيصال" : ""}
                      {r.adminNote ? ` • ${r.adminNote}` : ""}
                    </p>
                  </div>
                  {r.hasReceipt && (
                    <Button
                      size="sm"
                      variant="outline"
                      className="rounded-full gap-1 text-xs"
                      onClick={() => viewReceipt(r.id)}
                    >
                      <ImageIcon className="w-3.5 h-3.5" />
                      الإيصال
                    </Button>
                  )}
                  <Badge variant="outline" className={`text-[11px] ${meta.className}`}>
                    {meta.label}
                  </Badge>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* عرض الإيصال */}
      <Dialog open={receiptOpen} onOpenChange={setReceiptOpen}>
        <DialogContent className="rounded-3xl max-w-md">
          <DialogHeader>
            <DialogTitle>صورة الإيصال</DialogTitle>
          </DialogHeader>
          {receiptUrl && (
            <img src={receiptUrl} alt="إيصال الدفع" className="rounded-xl w-full" />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
