"use client";

import { useEffect, useState } from "react";
import { useStore, navigate } from "@/lib/store";
import { PLANS, FREE_MESSAGES_LIMIT } from "@/lib/plans";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  BookOpen,
  Mic2,
  Download,
  MessageCircle,
  Sparkles,
  Quote,
  Check,
  Headphones,
} from "lucide-react";

type Verse = {
  text: string;
  surah: number;
  surahName: string;
  ayah: number;
};

const FEATURES = [
  { icon: BookOpen, title: "١١٤ سورة كاملة", desc: "المصحف كاملاً بنص عثماني واضح" },
  { icon: Mic2, title: "أكثر من ٢٠ شيخ", desc: "اختر قارئك المفضل بجودة عالية" },
  { icon: Download, title: "تحميل السور", desc: "استمع دون اتصال في أي وقت" },
  { icon: MessageCircle, title: "محادثة ذكية", desc: "أسئلتك الشرعية بأدلة من القرآن" },
];

export function HomeView() {
  const user = useStore((s) => s.user);
  const [verse, setVerse] = useState<Verse | null>(null);

  useEffect(() => {
    fetch("/api/quran/verse")
      .then((r) => r.json())
      .then((d) => setVerse(d.verse))
      .catch(() => {});
  }, []);

  const goChat = () => (user ? navigate("/chat") : navigate("/login/register"));
  const goQuran = () => navigate("/quran");

  return (
    <div>
      {/* ---------- Hero ---------- */}
      <section className="relative overflow-hidden bg-gradient-to-bl from-islamic-900 via-islamic-800 to-islamic-700 text-white">
        <div className="absolute inset-0 pattern-bg opacity-20" aria-hidden="true" />
        <div
          className="absolute -top-24 -left-24 w-72 h-72 rounded-full bg-islamic-500/20 blur-3xl"
          aria-hidden="true"
        />
        <div
          className="absolute -bottom-32 -right-16 w-80 h-80 rounded-full bg-gold-soft/10 blur-3xl"
          aria-hidden="true"
        />
        <div className="relative max-w-6xl mx-auto px-4 py-16 md:py-24 text-center">
          <Badge
            variant="outline"
            className="mb-6 border-gold-soft/50 text-gold-soft bg-white/5 gap-1.5 px-4 py-1.5 text-sm"
          >
            <Sparkles className="w-4 h-4" />
            قرآنك ومحادثتك الإسلامية في مكان واحد
          </Badge>
          <h1 className="text-3xl md:text-6xl font-extrabold leading-[1.4] mb-5">
            القرآن الكريم والتلاوة
            <br />
            <span className="text-gold-soft">ومحادثة ذكية بإجابات من القرآن</span>
          </h1>
          <p className="text-emerald-100/85 md:text-lg max-w-2xl mx-auto leading-8 mb-8">
            استمع للمصحف كاملاً بصوت أشهر القرّاء، واطرح أسئلتك الشرعية وترى
            الإجابة مدعّمة بآيات من كتاب الله مع ذكر السورة والآية.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Button
              size="lg"
              onClick={goChat}
              className="bg-gold-soft text-islamic-900 hover:bg-gold-soft/90 text-base font-bold rounded-full px-8 shadow-lg shadow-black/20"
            >
              <MessageCircle className="w-5 h-5 ml-1" />
              ابدأ المحادثة الآن
            </Button>
            <Button
              size="lg"
              onClick={goQuran}
              className="bg-white/10 text-white hover:bg-white/20 border border-white/30 text-base font-bold rounded-full px-8"
            >
              <Headphones className="w-5 h-5 ml-1" />
              استمع للقرآن
            </Button>
          </div>
        </div>
      </section>

      {/* ---------- شريط المميزات ---------- */}
      <section className="max-w-6xl mx-auto px-4 -mt-8 relative z-10">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-4">
          {FEATURES.map((f, i) => (
            <Card
              key={i}
              className="border-border/70 shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all rounded-2xl"
            >
              <CardContent className="p-4 md:p-5 flex items-center gap-3">
                <div className="w-11 h-11 shrink-0 rounded-xl bg-islamic-50 text-islamic-700 flex items-center justify-center">
                  <f.icon className="w-5 h-5" />
                </div>
                <div className="min-w-0">
                  <p className="font-extrabold text-sm md:text-base text-islamic-800">
                    {f.title}
                  </p>
                  <p className="text-xs text-muted-foreground truncate">{f.desc}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* ---------- آية اليوم ---------- */}
      <section className="max-w-4xl mx-auto px-4 mt-12">
        <Card className="rounded-3xl border-gold-soft/60 shadow-sm overflow-hidden">
          <div className="bg-gradient-to-l from-gold-soft/15 via-transparent to-islamic-50 p-6 md:p-10 text-center">
            <div className="flex items-center justify-center gap-2 mb-5 text-gold">
              <Quote className="w-5 h-5 rotate-180" />
              <span className="font-extrabold text-sm tracking-wide">آية اليوم</span>
              <Quote className="w-5 h-5" />
            </div>
            {verse ? (
              <>
                <p className="font-quran text-2xl md:text-4xl leading-[2.2] text-islamic-900 mb-4">
                  {verse.text}
                </p>
                <button
                  onClick={() => navigate(`/surah/${verse.surah}`)}
                  className="text-sm font-bold text-islamic-600 hover:text-islamic-500 transition-colors"
                >
                  {verse.surahName} — الآية {verse.ayah} ↗
                </button>
              </>
            ) : (
              <div className="h-20 flex items-center justify-center">
                <div className="w-6 h-6 border-2 border-islamic-200 border-t-islamic-500 rounded-full animate-spin" />
              </div>
            )}
          </div>
        </Card>
      </section>

      {/* ---------- الباقات ---------- */}
      <section className="max-w-6xl mx-auto px-4 mt-14 mb-4">
        <div className="text-center mb-8">
          <h2 className="text-2xl md:text-3xl font-extrabold text-islamic-800">
            باقات بسيطة وواضحة
          </h2>
          <p className="text-muted-foreground mt-2">
            ابدأ مجاناً بـ {FREE_MESSAGES_LIMIT} رسالة، وترقَّ عندما تحب
          </p>
        </div>
        <div className="grid md:grid-cols-3 gap-4 md:gap-6 max-w-5xl mx-auto">
          {/* المجانية */}
          <Card className="rounded-3xl border-border/80 shadow-sm hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <h3 className="font-extrabold text-lg text-islamic-800 mb-1">المجانية</h3>
              <p className="text-3xl font-extrabold text-islamic-900 mb-4">
                ٠ <span className="text-sm font-semibold text-muted-foreground">جنيه</span>
              </p>
              <ul className="space-y-2.5 text-sm text-foreground/80 mb-6">
                <li className="flex gap-2 items-start">
                  <Check className="w-4 h-4 text-islamic-500 mt-0.5 shrink-0" />
                  {FREE_MESSAGES_LIMIT} رسالة محادثة كاملة
                </li>
                <li className="flex gap-2 items-start">
                  <Check className="w-4 h-4 text-islamic-500 mt-0.5 shrink-0" />
                  مصحف كامل وتلاوات مجاناً
                </li>
                <li className="flex gap-2 items-start">
                  <Check className="w-4 h-4 text-islamic-500 mt-0.5 shrink-0" />
                  سجل محادثات محفوظ
                </li>
              </ul>
              <Button
                variant="outline"
                className="w-full rounded-full"
                onClick={() => (user ? navigate("/chat") : navigate("/login/register"))}
              >
                ابدأ الآن
              </Button>
            </CardContent>
          </Card>

          {/* المدفوعة */}
          {PLANS.map((plan) => (
            <Card
              key={plan.id}
              className={`relative rounded-3xl shadow-sm hover:shadow-lg transition-all overflow-hidden ${
                plan.highlight
                  ? "border-islamic-600 ring-2 ring-islamic-500/40"
                  : "border-border/80"
              }`}
            >
              {plan.highlight && (
                <div className="absolute top-0 left-1/2 -translate-x-1/2 bg-gold-soft text-islamic-900 text-[11px] font-extrabold px-4 py-1 rounded-b-lg">
                  الأكثر قيمة
                </div>
              )}
              <CardContent className={`p-6 ${plan.highlight ? "pt-8" : ""}`}>
                <h3 className="font-extrabold text-lg text-islamic-800 mb-1">{plan.name}</h3>
                <p className="text-3xl font-extrabold text-islamic-900 mb-4">
                  {plan.priceEgp}{" "}
                  <span className="text-sm font-semibold text-muted-foreground">جنيه</span>
                </p>
                <ul className="space-y-2.5 text-sm text-foreground/80 mb-6">
                  {plan.features.map((f, i) => (
                    <li key={i} className="flex gap-2 items-start">
                      <Check className="w-4 h-4 text-islamic-500 mt-0.5 shrink-0" />
                      {f}
                    </li>
                  ))}
                </ul>
                <Button
                  className={`w-full rounded-full ${
                    plan.highlight
                      ? "bg-islamic-800 hover:bg-islamic-700"
                      : "bg-islamic-600 hover:bg-islamic-500"
                  }`}
                  onClick={() => navigate("/plans")}
                >
                  اشترك بـ {plan.priceEgp} جنيه
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      {/* ---------- دعوة أخيرة ---------- */}
      <section className="max-w-4xl mx-auto px-4 mt-10 mb-6">
        <div className="rounded-3xl bg-islamic-800 text-white p-8 md:p-10 text-center relative overflow-hidden">
          <div className="absolute inset-0 pattern-bg opacity-10" aria-hidden="true" />
          <h2 className="relative text-xl md:text-2xl font-extrabold mb-3">
            ﴿وَلَقَدْ يَسَّرْنَا الْقُرْآنَ لِلذِّكْرِ﴾
          </h2>
          <p className="relative text-emerald-100/80 text-sm mb-6">
            ابدأ رحلتك مع كتاب الله اليوم — استماع، تلاوة، وفهم
          </p>
          <Button
            size="lg"
            onClick={goQuran}
            className="relative bg-gold-soft text-islamic-900 hover:bg-gold-soft/90 font-bold rounded-full px-8"
          >
            افتح المصحف الآن
          </Button>
        </div>
      </section>
    </div>
  );
}
