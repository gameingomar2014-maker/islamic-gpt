"use client";

import { useCallback, useEffect, useState } from "react";
import { useStore, navigate } from "@/lib/store";
import { getPlan, paymentLabel } from "@/lib/plans";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import {
  Users,
  Hourglass,
  BadgeCheck,
  Banknote,
  ShieldCheck,
  Check,
  X,
  Image as ImageIcon,
  RefreshCw,
  User as UserIcon,
} from "lucide-react";

type Stats = {
  users: number;
  pendingRequests: number;
  approvedRequests: number;
  rejectedRequests: number;
  activeSubscriptions: number;
  totalRevenueEgp: number;
};

type AdminRequest = {
  id: string;
  planId: string;
  userName: string;
  phone: string;
  paymentMethod: string;
  transactionRef: string | null;
  status: "PENDING" | "APPROVED" | "REJECTED";
  amount: number;
  words: number;
  adminNote: string | null;
  createdAt: string;
  userId: string;
  user: { email: string };
  hasReceipt: boolean;
};

const STATUS_META: Record<string, { label: string; className: string }> = {
  PENDING: { label: "بانتظار المراجعة", className: "bg-amber-50 text-amber-700 border-amber-300" },
  APPROVED: { label: "مقبول", className: "bg-emerald-50 text-emerald-700 border-emerald-300" },
  REJECTED: { label: "مرفوض", className: "bg-red-50 text-red-700 border-red-300" },
};

function fmtDate(iso: string): string {
  try {
    return new Date(iso).toLocaleDateString("ar-EG", {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  } catch {
    return iso;
  }
}

export function AdminView() {
  const user = useStore((s) => s.user);
  const authLoading = useStore((s) => s.authLoading);
  const refreshMe = useStore((s) => s.refreshMe);
  const { toast } = useToast();
  const [stats, setStats] = useState<Stats | null>(null);
  const [requests, setRequests] = useState<AdminRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [receipt, setReceipt] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [statsRes, reqRes] = await Promise.all([
        fetch("/api/admin/stats"),
        fetch("/api/admin/requests"),
      ]);
      if (statsRes.ok) {
        const d = await statsRes.json();
        setStats(d.stats);
      }
      if (reqRes.ok) {
        const d = await reqRes.json();
        setRequests(d.requests ?? []);
      }
    } catch {
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (!authLoading && user?.role === "ADMIN") load();
  }, [user, authLoading, load]);

  const review = async (id: string, action: "approve" | "reject") => {
    setBusyId(id);
    try {
      const res = await fetch(`/api/admin/requests/${id}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast({ title: "تعذّر تنفيذ العملية", description: data.error, variant: "destructive" });
        return;
      }
      toast({
        title: action === "approve" ? "تمت الموافقة والتفعيل" : "تم رفض الطلب",
        description: data.message,
      });
      load();
      refreshMe();
    } catch {
      toast({ title: "خطأ في الاتصال", variant: "destructive" });
    } finally {
      setBusyId(null);
    }
  };

  const viewReceipt = async (id: string) => {
    try {
      const res = await fetch(`/api/admin/requests/${id}/receipt`);
      if (!res.ok) return;
      const d = await res.json();
      setReceipt(d.receiptImage);
    } catch {}
  };

  // غير مصرح
  if (!authLoading && (!user || user.role !== "ADMIN")) {
    return (
      <div className="max-w-md mx-auto px-4 py-16 text-center">
        <ShieldCheck className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
        <h1 className="text-xl font-extrabold text-islamic-800 mb-2">لوحة الإدارة</h1>
        <p className="text-sm text-muted-foreground mb-6">
          هذه المنطقة مخصصة للأدمن فقط. سجّل الدخول بحساب أدمن للوصول.
        </p>
        <Button className="bg-islamic-800 rounded-full" onClick={() => navigate("/login")}>
          تسجيل الدخول
        </Button>
      </div>
    );
  }

  const statCards = stats
    ? [
        { icon: Users, label: "المستخدمون", value: stats.users, color: "bg-islamic-50 text-islamic-700" },
        { icon: Hourglass, label: "طلبات معلّقة", value: stats.pendingRequests, color: "bg-amber-50 text-amber-700" },
        { icon: BadgeCheck, label: "اشتراكات مفعّلة", value: stats.activeSubscriptions, color: "bg-emerald-50 text-emerald-700" },
        { icon: Banknote, label: "إجمالي الإيراد (جنيه)", value: stats.totalRevenueEgp, color: "bg-gold-soft/20 text-gold" },
      ]
    : [];

  return (
    <div className="max-w-6xl mx-auto px-4 py-6 md:py-10">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-extrabold text-islamic-800 flex items-center gap-2">
          <ShieldCheck className="w-7 h-7 text-islamic-600" />
          لوحة الإدارة
        </h1>
        <Button variant="outline" size="sm" className="rounded-full gap-2" onClick={load}>
          <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
          تحديث
        </Button>
      </div>

      {/* الإحصائيات */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-8">
        {stats
          ? statCards.map((s, i) => (
              <Card key={i} className="rounded-2xl border-border/70 shadow-sm">
                <CardContent className="p-4 flex items-center gap-3">
                  <div className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${s.color}`}>
                    <s.icon className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-xs text-muted-foreground font-bold">{s.label}</p>
                    <p className="text-2xl font-extrabold text-islamic-900 tabular-nums">{s.value}</p>
                  </div>
                </CardContent>
              </Card>
            ))
          : Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-20 rounded-2xl" />)}
      </div>

      {/* جدول الطلبات */}
      <h2 className="text-lg font-extrabold text-islamic-800 mb-3">طلبات الاشتراك</h2>
      <Card className="rounded-2xl border-border/70 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm min-w-[760px]">
            <thead>
              <tr className="bg-secondary/70 text-islamic-800">
                <th className="text-right font-bold px-4 py-3">المستخدم</th>
                <th className="text-right font-bold px-4 py-3">الباقة</th>
                <th className="text-right font-bold px-4 py-3">المبلغ</th>
                <th className="text-right font-bold px-4 py-3">طريقة الدفع</th>
                <th className="text-right font-bold px-4 py-3">التاريخ</th>
                <th className="text-right font-bold px-4 py-3">الحالة</th>
                <th className="text-center font-bold px-4 py-3">الإجراء</th>
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr>
                  <td colSpan={7} className="px-4 py-10 text-center text-muted-foreground">
                    جارٍ التحميل…
                  </td>
                </tr>
              ) : requests.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-4 py-10 text-center text-muted-foreground">
                    لا توجد طلبات بعد
                  </td>
                </tr>
              ) : (
                requests.map((r) => {
                  const meta = STATUS_META[r.status] ?? STATUS_META.PENDING;
                  const isPending = r.status === "PENDING";
                  return (
                    <tr
                      key={r.id}
                      className={`border-t border-border/60 ${isPending ? "bg-amber-50/30" : ""}`}
                    >
                      <td className="px-4 py-3">
                        <p className="font-bold text-islamic-900">{r.userName}</p>
                        <p className="text-[11px] text-muted-foreground flex items-center gap-1" dir="ltr">
                          <UserIcon className="w-3 h-3" />
                          {r.user.email}
                        </p>
                        <p className="text-[11px] text-muted-foreground" dir="ltr">
                          {r.phone}
                        </p>
                      </td>
                      <td className="px-4 py-3">
                        <p className="font-semibold">{getPlan(r.planId)?.name ?? r.planId}</p>
                        <p className="text-[11px] text-muted-foreground">{r.words} كلمة</p>
                      </td>
                      <td className="px-4 py-3 font-extrabold text-islamic-800 tabular-nums">
                        {r.amount} ج
                      </td>
                      <td className="px-4 py-3">
                        <p>{paymentLabel(r.paymentMethod)}</p>
                        {r.transactionRef && (
                          <p className="text-[11px] text-muted-foreground" dir="ltr">
                            {r.transactionRef}
                          </p>
                        )}
                        {r.hasReceipt && (
                          <button
                            onClick={() => viewReceipt(r.id)}
                            className="text-[11px] font-bold text-islamic-600 hover:underline flex items-center gap-1 mt-0.5"
                          >
                            <ImageIcon className="w-3 h-3" />
                            عرض الإيصال
                          </button>
                        )}
                      </td>
                      <td className="px-4 py-3 text-xs text-muted-foreground">
                        {fmtDate(r.createdAt)}
                      </td>
                      <td className="px-4 py-3">
                        <Badge variant="outline" className={`text-[11px] ${meta.className}`}>
                          {meta.label}
                        </Badge>
                        {r.adminNote && (
                          <p className="text-[10px] text-muted-foreground mt-1 max-w-32 truncate">
                            {r.adminNote}
                          </p>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        {isPending ? (
                          <div className="flex items-center justify-center gap-1.5">
                            <Button
                              size="sm"
                              className="rounded-full bg-emerald-600 hover:bg-emerald-500 gap-1 h-8 px-3"
                              disabled={busyId === r.id}
                              onClick={() => review(r.id, "approve")}
                            >
                              <Check className="w-3.5 h-3.5" />
                              موافقة
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              className="rounded-full text-destructive border-red-200 hover:bg-red-50 gap-1 h-8 px-3"
                              disabled={busyId === r.id}
                              onClick={() => review(r.id, "reject")}
                            >
                              <X className="w-3.5 h-3.5" />
                              رفض
                            </Button>
                          </div>
                        ) : (
                          <p className="text-center text-[11px] text-muted-foreground">
                            تمت المراجعة
                          </p>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </Card>

      {/* عرض الإيصال */}
      <Dialog open={!!receipt} onOpenChange={(o) => !o && setReceipt(null)}>
        <DialogContent className="rounded-3xl max-w-md">
          <DialogHeader>
            <DialogTitle>إيصال الدفع</DialogTitle>
          </DialogHeader>
          {receipt && (
            <img src={receipt} alt="إيصال الدفع" className="rounded-xl w-full" />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
