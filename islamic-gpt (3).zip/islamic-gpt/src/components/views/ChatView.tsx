"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useStore, navigate } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { FREE_MESSAGES_LIMIT } from "@/lib/plans";
import { Send, Plus, MessageCircle, Sparkles, BookMarked, Droplets, MoonStar, Clock3, Trash2, Menu, X, Wallet, AlertCircle } from "lucide-react";
import ReactMarkdown from "react-markdown";

// مكونات عرض Markdown للردود
const mdComponents = {
  h1: (p: React.HTMLAttributes<HTMLHeadingElement>) => (
    <h3 className="font-extrabold text-[15px] text-islamic-800 mt-3 mb-1.5 first:mt-0" {...p} />
  ),
  h2: (p: React.HTMLAttributes<HTMLHeadingElement>) => (
    <h3 className="font-extrabold text-[15px] text-islamic-800 mt-3 mb-1.5 first:mt-0" {...p} />
  ),
  h3: (p: React.HTMLAttributes<HTMLHeadingElement>) => (
    <h4 className="font-extrabold text-sm text-islamic-800 mt-3 mb-1.5 first:mt-0" {...p} />
  ),
  ul: (p: React.HTMLAttributes<HTMLUListElement>) => (
    <ul className="list-disc pr-5 my-2 space-y-1.5" {...p} />
  ),
  ol: (p: React.HTMLAttributes<HTMLOListElement>) => (
    <ol className="list-decimal pr-5 my-2 space-y-1.5" {...p} />
  ),
  li: (p: React.HTMLAttributes<HTMLLIElement>) => <li className="leading-7" {...p} />,
  p: (p: React.HTMLAttributes<HTMLParagraphElement>) => (
    <p className="my-2 first:mt-0 last:mb-0 leading-7" {...p} />
  ),
  strong: (p: React.HTMLAttributes<HTMLElement>) => (
    <strong className="font-extrabold text-islamic-900" {...p} />
  ),
  blockquote: (p: React.HTMLAttributes<HTMLQuoteElement>) => (
    <blockquote className="border-r-2 border-gold-soft pr-3 my-2 text-foreground/80" {...p} />
  ),
};

type Msg = {
  id?: string;
  role: "USER" | "ASSISTANT";
  content: string;
};

type SessionInfo = {
  id: string;
  title: string;
  updatedAt: string;
  _count?: { messages: number };
};

const QUICK_QUESTIONS = [
  { icon: Droplets, text: "ما خطوات الوضوء من القرآن والسنة؟" },
  { icon: MoonStar, text: "ما أحكام الصيام الأساسية؟" },
  { icon: Clock3, text: "اذكر لي آيات عن مواقيت الصلاة وأهميتها" },
  { icon: BookMarked, text: "ما فضل قراءة القرآن وذكر آيات في ذلك؟" },
];

function renderAyahContent(content: string) {
  // إبراز الآيات بين ﴿ ﴾ بلون ذهبي داخل عرض Markdown
  const parts = content.split(/(﴿[^﴾]+﴾)/g);
  return parts.map((part, i) =>
    part.startsWith("﴿") && part.endsWith("﴾") ? (
      <span key={i} className="text-gold font-quran text-[1.15em]">
        {part}
      </span>
    ) : (
      <ReactMarkdown key={i} components={mdComponents}>
        {part}
      </ReactMarkdown>
    )
  );
}

export function ChatView() {
  const user = useStore((s) => s.user);
  const authLoading = useStore((s) => s.authLoading);
  const refreshMe = useStore((s) => s.refreshMe);

  const [sessions, setSessions] = useState<SessionInfo[]>([]);
  const [currentSession, setCurrentSession] = useState<string | null>(null);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [exhausted, setExhausted] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);

  const loadSessions = useCallback(async () => {
    try {
      const res = await fetch("/api/chat/sessions");
      if (res.ok) {
        const d = await res.json();
        setSessions(d.sessions ?? []);
      }
    } catch {}
  }, []);

  useEffect(() => {
    if (user) loadSessions();
  }, [user, loadSessions]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages, sending]);

  const openSession = async (id: string) => {
    setSidebarOpen(false);
    try {
      const res = await fetch(`/api/chat/sessions/${id}`);
      if (!res.ok) return;
      const d = await res.json();
      setCurrentSession(d.session.id);
      setMessages(d.messages);
    } catch {}
  };

  const newChat = () => {
    setCurrentSession(null);
    setMessages([]);
    setSidebarOpen(false);
    setError(null);
  };

  const deleteSession = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      await fetch(`/api/chat/sessions/${id}`, { method: "DELETE" });
      if (currentSession === id) newChat();
      loadSessions();
    } catch {}
  };

  const send = async (text?: string) => {
    const message = (text ?? input).trim();
    if (!message || sending || !user) return;
    setInput("");
    setError(null);
    setMessages((m) => [...m, { role: "USER", content: message }]);
    setSending(true);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sessionId: currentSession ?? undefined, message }),
      });
      const data = await res.json();

      if (res.status === 402) {
        setMessages((m) => m.slice(0, -1));
        setInput(message);
        setExhausted(true);
        return;
      }
      if (!res.ok) {
        setError(data.error ?? "حدث خطأ، حاول مرة أخرى");
        setMessages((m) => m.slice(0, -1));
        setInput(message);
        return;
      }

      setMessages((m) => [...m, { role: "ASSISTANT", content: data.reply }]);
      setCurrentSession(data.sessionId);
      refreshMe();
      loadSessions();
    } catch {
      setError("تعذّر الاتصال بالسيرفر، تحقق من الإنترنت وحاول مجدداً");
      setMessages((m) => m.slice(0, -1));
      setInput(message);
    } finally {
      setSending(false);
    }
  };

  // ---------- غير مسجل ----------
  if (!authLoading && !user) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-16 text-center">
        <div className="w-20 h-20 mx-auto rounded-3xl bg-islamic-50 flex items-center justify-center mb-6">
          <MessageCircle className="w-10 h-10 text-islamic-600" />
        </div>
        <h1 className="text-2xl font-extrabold text-islamic-800 mb-3">
          المحادثة الإسلامية الذكية
        </h1>
        <p className="text-muted-foreground leading-8 mb-8">
          اسأل عن العقيدة والعبادات والآداب والأحكام، وستجد إجابة مدعّمة بآيات
          من القرآن الكريم مع ذكر السورة والآية. سجّل دخولك للبدء — أول {FREE_MESSAGES_LIMIT} رسالة مجانية تماماً.
        </p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Button
            size="lg"
            className="bg-islamic-800 hover:bg-islamic-700 rounded-full px-8"
            onClick={() => navigate("/login")}
          >
            تسجيل الدخول
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="rounded-full px-8"
            onClick={() => navigate("/login/register")}
          >
            حساب جديد مجاني
          </Button>
        </div>
      </div>
    );
  }

  if (authLoading) {
    return (
      <div className="max-w-3xl mx-auto px-4 py-10">
        <div className="w-8 h-8 border-2 border-islamic-200 border-t-islamic-500 rounded-full animate-spin mx-auto mt-20" />
      </div>
    );
  }

  const isFree = user?.plan === "FREE";
  const remaining = user
    ? isFree
      ? Math.max(0, FREE_MESSAGES_LIMIT - user.freeMessagesUsed)
      : user.wordBalance
    : 0;

  return (
    <div className="max-w-6xl mx-auto px-4 py-4 md:py-6">
      <div className="flex gap-4">
        {/* ---------- الشريط الجانبي: سجل المحادثات ---------- */}
        <aside
          className={`fixed lg:static inset-y-0 right-0 z-50 w-72 bg-white lg:bg-transparent lg:w-64 shrink-0 transform transition-transform duration-300 ${
            sidebarOpen ? "translate-x-0" : "translate-x-full lg:translate-x-0"
          } lg:translate-x-0`}
        >
          <Card className="h-full rounded-none lg:rounded-2xl border-y lg:border border-border/70 shadow-sm flex flex-col">
            <CardContent className="p-3 flex-1 flex flex-col min-h-0">
              <div className="flex items-center justify-between mb-3">
                <h2 className="font-extrabold text-sm text-islamic-800">سجل المحادثات</h2>
                <button
                  className="lg:hidden p-1 text-muted-foreground"
                  onClick={() => setSidebarOpen(false)}
                  aria-label="إغلاق السجل"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <Button
                onClick={newChat}
                className="w-full rounded-full bg-islamic-800 hover:bg-islamic-700 gap-2 mb-3"
                size="sm"
              >
                <Plus className="w-4 h-4" />
                محادثة جديدة
              </Button>
              <div className="flex-1 overflow-y-auto space-y-1 max-h-[60vh] lg:max-h-[65vh]">
                {sessions.length === 0 ? (
                  <p className="text-xs text-muted-foreground text-center py-6 leading-6">
                    لا توجد محادثات بعد
                    <br />
                    ابدأ أول محادثة لك الآن
                  </p>
                ) : (
                  sessions.map((s) => (
                    <div
                      key={s.id}
                      onClick={() => openSession(s.id)}
                      className={`group flex items-center gap-2 px-3 py-2.5 rounded-xl cursor-pointer text-sm transition-colors ${
                        currentSession === s.id
                          ? "bg-islamic-50 text-islamic-800 font-bold"
                          : "hover:bg-secondary text-foreground/80"
                      }`}
                    >
                      <MessageCircle className="w-4 h-4 shrink-0 opacity-60" />
                      <span className="flex-1 truncate">{s.title}</span>
                      <button
                        onClick={(e) => deleteSession(s.id, e)}
                        className="opacity-0 group-hover:opacity-100 text-muted-foreground hover:text-destructive transition-opacity"
                        aria-label="حذف المحادثة"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))
                )}
              </div>
              {/* الرصيد */}
              {user && (
                <div className="mt-3 pt-3 border-t border-border/70">
                  <div className="rounded-xl bg-islamic-50 p-3">
                    <div className="flex items-center gap-1.5 text-xs font-bold text-islamic-800 mb-1">
                      <Wallet className="w-3.5 h-3.5" />
                      رصيدك المتبقي
                    </div>
                    <p className="text-lg font-extrabold text-islamic-900">
                      {isFree ? `${remaining} رسالة` : `${remaining} كلمة`}
                    </p>
                    <button
                      onClick={() => navigate("/plans")}
                      className="text-[11px] text-gold hover:underline font-bold mt-1"
                    >
                      ترقية الباقة ↑
                    </button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </aside>

        {sidebarOpen && (
          <div
            className="fixed inset-0 bg-black/30 z-40 lg:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}

        {/* ---------- منطقة المحادثة ---------- */}
        <div className="flex-1 min-w-0">
          <Card className="rounded-2xl border-border/70 shadow-sm flex flex-col h-[calc(100vh-13rem)] md:h-[calc(100vh-12rem)]">
            {/* رأس المحادثة */}
            <div className="flex items-center justify-between px-4 py-3 border-b border-border/60">
              <div className="flex items-center gap-2 min-w-0">
                <button
                  className="lg:hidden p-1.5 text-muted-foreground"
                  onClick={() => setSidebarOpen(true)}
                  aria-label="فتح سجل المحادثات"
                >
                  <Menu className="w-5 h-5" />
                </button>
                <div className="w-9 h-9 rounded-full bg-islamic-800 flex items-center justify-center shrink-0">
                  <Sparkles className="w-4.5 h-4.5 w-[18px] h-[18px] text-gold-soft" />
                </div>
                <div className="min-w-0">
                  <p className="font-extrabold text-sm text-islamic-800">المحادثة الإسلامية</p>
                  <p className="text-[11px] text-muted-foreground">
                    إجابات مدعّمة بآيات من القرآن
                  </p>
                </div>
              </div>
              <Badge
                variant="outline"
                className={`shrink-0 text-[11px] ${
                  remaining <= (isFree ? 5 : 50)
                    ? "border-amber-300 bg-amber-50 text-amber-700"
                    : "border-emerald-200 bg-islamic-50 text-islamic-700"
                }`}
              >
                {isFree ? `متبقي ${remaining} من ${FREE_MESSAGES_LIMIT}` : `${remaining} كلمة`}
              </Badge>
            </div>

            {/* الرسائل */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gradient-to-b from-background to-islamic-50/40">
              {messages.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center px-4">
                  <div className="w-16 h-16 rounded-2xl bg-islamic-800 flex items-center justify-center mb-4 animate-float-soft">
                    <Sparkles className="w-8 h-8 text-gold-soft" />
                  </div>
                  <h3 className="font-extrabold text-islamic-800 mb-2">
                    السلام عليكم ورحمة الله {user?.name ? `يا ${user.name.split(" ")[0]}` : ""}
                  </h3>
                  <p className="text-sm text-muted-foreground mb-6 max-w-md leading-7">
                    اسألني عن أي موضوع إسلامي — وسيكون الجواب مستنداً إلى آيات
                    القرآن الكريم مع ذكر المصدر، ومع بيان مواضع خلاف العلماء إن
                    وجدت.
                  </p>
                  <div className="grid sm:grid-cols-2 gap-2 w-full max-w-lg">
                    {QUICK_QUESTIONS.map((q, i) => (
                      <button
                        key={i}
                        onClick={() => send(q.text)}
                        className="flex items-center gap-2.5 p-3 rounded-xl bg-white border border-border/70 text-right text-xs font-semibold text-foreground/80 hover:border-islamic-400 hover:bg-islamic-50 transition-all"
                      >
                        <q.icon className="w-4 h-4 text-islamic-600 shrink-0" />
                        {q.text}
                      </button>
                    ))}
                  </div>
                </div>
              ) : (
                messages.map((m, i) => (
                  <div
                    key={m.id ?? i}
                    className={`flex ${m.role === "USER" ? "justify-start" : "justify-end"}`}
                  >
                    <div
                      className={`max-w-[85%] md:max-w-[75%] rounded-2xl px-4 py-3 text-sm ${
                        m.role === "USER"
                          ? "bg-islamic-800 text-white rounded-br-md whitespace-pre-wrap leading-7"
                          : "bg-white border border-border/60 text-foreground rounded-bl-md shadow-sm"
                      }`}
                    >
                      {m.role === "ASSISTANT" ? renderAyahContent(m.content) : m.content}
                    </div>
                  </div>
                ))
              )}
              {sending && (
                <div className="flex justify-end">
                  <div className="bg-white border border-border/60 rounded-2xl rounded-bl-md px-4 py-3 shadow-sm">
                    <div className="flex gap-1.5">
                      {[0, 1, 2].map((i) => (
                        <span
                          key={i}
                          className="w-2 h-2 bg-islamic-400 rounded-full animate-bounce"
                          style={{ animationDelay: `${i * 0.15}s` }}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              )}
              {error && (
                <div className="flex justify-end">
                  <div className="bg-red-50 border border-red-200 text-red-700 rounded-xl px-4 py-2.5 text-xs flex items-center gap-2">
                    <AlertCircle className="w-4 h-4" />
                    {error}
                  </div>
                </div>
              )}
              <div ref={bottomRef} />
            </div>

            {/* حقل الكتابة */}
            <div className="p-3 border-t border-border/60 bg-white rounded-b-2xl">
              <div className="flex items-end gap-2">
                <Textarea
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && !e.shiftKey) {
                      e.preventDefault();
                      send();
                    }
                  }}
                  placeholder="اكتب سؤالك هنا… (Enter للإرسال)"
                  className="min-h-11 max-h-32 resize-none rounded-xl border-border bg-background text-sm"
                  rows={1}
                  aria-label="نص السؤال"
                />
                <Button
                  onClick={() => send()}
                  disabled={sending || !input.trim()}
                  size="icon"
                  className="rounded-xl w-11 h-11 bg-islamic-800 hover:bg-islamic-700 shrink-0"
                  aria-label="إرسال"
                >
                  <Send className="w-4 h-4 -scale-x-100" />
                </Button>
              </div>
              <p className="text-[10px] text-muted-foreground mt-2 text-center">
                المعلومات هنا للفهم والمعرفة — الفتوى الشخصية تُؤخذ من عالم موثوق
              </p>
            </div>
          </Card>
        </div>
      </div>

      {/* نافذة انتهاء الرصيد */}
      <Dialog open={exhausted} onOpenChange={setExhausted}>
        <DialogContent className="rounded-3xl max-w-md text-center">
          <DialogHeader>
            <div className="mx-auto w-16 h-16 rounded-2xl bg-gold-soft/20 flex items-center justify-center mb-2">
              <Sparkles className="w-8 h-8 text-gold" />
            </div>
            <DialogTitle className="text-xl font-extrabold text-islamic-800">
              انتهى رصيدك
            </DialogTitle>
            <DialogDescription className="leading-7 pt-2 text-sm">
              {isFree
                ? `استخدمت رسائلك المجانية الـ ${FREE_MESSAGES_LIMIT} كاملة. اشترك في باقة مناسبة ليكمل الحديث معك — والأسعار تبدأ من ٥٠ جنيه فقط.`
                : "انتهى رصيد كلماتك في الباقة الحالية. يمكنك تجديد الاشتراك لمواصلة المحادثة."}
            </DialogDescription>
          </DialogHeader>
          <div className="flex flex-col gap-2 pt-2">
            <Button
              className="bg-islamic-800 hover:bg-islamic-700 rounded-full"
              onClick={() => {
                setExhausted(false);
                navigate("/plans");
              }}
            >
              عرض الباقات والاشتراك
            </Button>
            <Button variant="ghost" onClick={() => setExhausted(false)}>
              لاحقاً
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
