"use client";

import { MosqueLogo } from "@/components/layout/AppShell";
import { Card, CardContent } from "@/components/ui/card";
import { useStore, navigate } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { BookOpen, Mic2, Sparkles, ShieldAlert, ExternalLink } from "lucide-react";

export function AboutView() {
  const user = useStore((s) => s.user);
  return (
    <div className="max-w-3xl mx-auto px-4 py-8 md:py-12">
      <div className="text-center mb-10">
        <MosqueLogo className="w-16 h-16 mx-auto mb-4" />
        <h1 className="text-2xl md:text-3xl font-extrabold text-islamic-800">
          عن موقع Islamic GPT
        </h1>
        <p className="text-muted-foreground mt-3 leading-8 max-w-xl mx-auto">
          منصة إسلامية واحدة تجمع بين سماع القرآن الكريم وقراءته وفهمه، ومحادثة
          ذكية تجيب أسئلتك مستندة إلى كتاب الله — بصدق في المصادر ووضوح في
          الحدود.
        </p>
      </div>

      <div className="space-y-4">
        <Card className="rounded-3xl border-border/70 shadow-sm">
          <CardContent className="p-6 md:p-8">
            <h2 className="font-extrabold text-lg text-islamic-800 mb-4 flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-islamic-600" />
              مصادر المحتوى (مفتوحة وموثوقة)
            </h2>
            <ul className="space-y-4 text-sm leading-8 text-foreground/85">
              <li className="flex gap-3">
                <span className="w-2 h-2 rounded-full bg-gold-soft mt-3 shrink-0" />
                <span>
                  <b>نص القرآن الكريم:</b> رواية حفص عن عاصم بنسخة عثمانية، من
                  مشروع AlQuran Cloud المفتوح المصدر{" "}
                  <a
                    href="https://alquran.cloud"
                    target="_blank"
                    rel="noreferrer"
                    className="text-islamic-600 font-bold hover:underline inline-flex items-center gap-0.5"
                    dir="ltr"
                  >
                    alquran.cloud <ExternalLink className="w-3 h-3" />
                  </a>
                </span>
              </li>
              <li className="flex gap-3">
                <span className="w-2 h-2 rounded-full bg-gold-soft mt-3 shrink-0" />
                <span>
                  <b>التلاوات الصوتية:</b> أكثر من ٢٠ شيخاً، من موقع{" "}
                  <a
                    href="https://mp3quran.net"
                    target="_blank"
                    rel="noreferrer"
                    className="text-islamic-600 font-bold hover:underline inline-flex items-center gap-0.5"
                    dir="ltr"
                  >
                    mp3quran.net <ExternalLink className="w-3 h-3" />
                  </a>{" "}
                  — مكتبة تلاوات مجانية معروفة وموثوقة.
                </span>
              </li>
              <li className="flex gap-3">
                <span className="w-2 h-2 rounded-full bg-gold-soft mt-3 shrink-0" />
                <span>
                  <b>المحادثة الذكية:</b> تعتمد على بحث حقيقي داخل نص القرآن
                  الكريم المخزّن في قاعدة بياناتنا (٦٢٣٦ آية)، وتُعرض الآيات
                  ذات الصلة على النموذج ليستند إليها في الإجابة مع ذكر السورة
                  والآية.
                </span>
              </li>
            </ul>
          </CardContent>
        </Card>

        <Card className="rounded-3xl border-border/70 shadow-sm">
          <CardContent className="p-6 md:p-8">
            <h2 className="font-extrabold text-lg text-islamic-800 mb-4 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-islamic-600" />
              ماذا يقدم لك الموقع؟
            </h2>
            <div className="grid sm:grid-cols-2 gap-4 text-sm leading-7">
              <div className="rounded-2xl bg-islamic-50 p-4">
                <p className="font-extrabold text-islamic-800 mb-1">مصحف كامل</p>
                <p className="text-muted-foreground">
                  ١١٤ سورة بنص عثماني، بحث سريع، تحميل السور، ومتابعة تلقائية
                  لآخر موضع أوقفت عنده.
                </p>
              </div>
              <div className="rounded-2xl bg-islamic-50 p-4">
                <p className="font-extrabold text-islamic-800 mb-1">تلاوة عالية الجودة</p>
                <p className="text-muted-foreground">
                  اختر قارئك من نخبة القرّاء، وتحكم في السرعة والتقدم أثناء
                  الاستماع من أي صفحة.
                </p>
              </div>
              <div className="rounded-2xl bg-islamic-50 p-4">
                <p className="font-extrabold text-islamic-800 mb-1">محادثة إسلامية أمينة</p>
                <p className="text-muted-foreground">
                  إجابات مع آيات ومصادرها، وبيان صريح لمواضع خلاف العلماء، وتنبيه
                  دائم بأخذ الفتوى الشخصية من عالم موثوق.
                </p>
              </div>
              <div className="rounded-2xl bg-islamic-50 p-4">
                <p className="font-extrabold text-islamic-800 mb-1">باقات واضحة</p>
                <p className="text-muted-foreground">
                  رصيد مجاني تجريبي، وباقات مدفوعة بسيطة، ودفع يدوي يتم تفعيله
                  بعد مراجعة الإدارة.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="rounded-3xl border-amber-200 bg-amber-50/50">
          <CardContent className="p-6 md:p-8">
            <h2 className="font-extrabold text-lg text-amber-800 mb-3 flex items-center gap-2">
              <ShieldAlert className="w-5 h-5" />
              تنبيه مهم وحدود الأداة
            </h2>
            <ul className="space-y-2.5 text-sm leading-7 text-amber-900/90">
              <li>• المحادثة الذكية وسيلة للفهم والتعلم، وليست مفتياً ولا بديلاً عن أهل العلم.</li>
              <li>• الفتوى الشخصية والتفصيلية تُؤخذ من عالم موثوق تثق به.</li>
              <li>• الموقع لا يخترع آيات أو أحاديث، وإذا لم يجد مصدراً يذكر ذلك بصراحة.</li>
              <li>• إن وجدت أي خطأ في النصوص أو الإجابات فتواصل معنا لتصحيحه، وجزاك الله خيراً.</li>
            </ul>
          </CardContent>
        </Card>

        <div className="text-center pt-4 pb-2">
          <Button
            size="lg"
            className="bg-islamic-800 hover:bg-islamic-700 rounded-full px-10"
            onClick={() => navigate(user ? "/chat" : "/login/register")}
          >
            {user ? "ابدأ المحادثة" : "أنشئ حسابك المجاني"}
          </Button>
        </div>
      </div>
    </div>
  );
}
