"use client";

import { useEffect, useState } from "react";
import { useStore, navigate } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { MosqueLogo } from "@/components/layout/AppShell";
import { FREE_MESSAGES_LIMIT } from "@/lib/plans";
import { useToast } from "@/hooks/use-toast";
import {
  LogIn,
  UserPlus,
  Mail,
  KeyRound,
  User,
  ShieldCheck,
  ArrowRight,
} from "lucide-react";

export function AuthView({ initialMode }: { initialMode: "login" | "register" }) {
  const user = useStore((s) => s.user);
  const refreshMe = useStore((s) => s.refreshMe);
  const { toast } = useToast();
  const [mode, setMode] = useState<"login" | "register">(initialMode);
  const [adminMode, setAdminMode] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    setMode(initialMode);
    setAdminMode(false);
  }, [initialMode]);
  useEffect(() => {
    if (user) navigate("/");
  }, [user]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    try {
      const res = await fetch(`/api/auth/${mode}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(
          mode === "login" ? { email, password } : { name, email, password }
        ),
      });
      const data = await res.json();
      if (!res.ok) {
        toast({
          title: mode === "login" ? "تعذّر تسجيل الدخول" : "تعذّر إنشاء الحساب",
          description: data.error,
          variant: "destructive",
        });
        return;
      }
      // في وضع دخول الإدارة: لا يُسمح إلا بحسابات ADMIN
      if (mode === "login" && adminMode && data.user?.role !== "ADMIN") {
        await fetch("/api/auth/logout", { method: "POST" });
        toast({
          title: "هذا الحساب ليس حساب إدارة",
          description: "استخدم دخول الأعضاء العادي أو تواصل مع المشرف",
          variant: "destructive",
        });
        return;
      }
      await refreshMe();
      toast({
        title:
          mode === "login"
            ? adminMode
              ? "مرحباً بك أيها المشرف"
              : "أهلاً بعودتك"
            : "تم إنشاء حسابك بنجاح",
        description:
          mode === "login"
            ? `مرحباً ${data.user?.name ?? ""}`
            : `أهلاً بك! رصيدك المبدئي ${FREE_MESSAGES_LIMIT} رسالة مجانية`,
      });
      navigate("/");
    } catch {
      toast({ title: "خطأ في الاتصال", variant: "destructive" });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="max-w-md mx-auto px-4 py-8 md:py-14">
      <Card className="rounded-3xl border-border/70 shadow-lg overflow-hidden">
        <div className="bg-gradient-to-bl from-islamic-900 to-islamic-700 p-8 text-center text-white relative">
          <div className="absolute inset-0 pattern-bg opacity-15" aria-hidden="true" />
          <div className="relative">
            {adminMode && mode === "login" ? (
              <div className="w-14 h-14 mx-auto mb-3 rounded-2xl bg-gold/15 border border-gold/40 flex items-center justify-center">
                <ShieldCheck className="w-8 h-8 text-gold-soft" />
              </div>
            ) : (
              <MosqueLogo className="w-14 h-14 mx-auto mb-3" />
            )}
            <h1 className="text-xl font-extrabold mb-1">
              {mode === "register"
                ? "حساب جديد"
                : adminMode
                  ? "تسجيل دخول الإدارة"
                  : "تسجيل الدخول"}
            </h1>
            <p className="text-emerald-100/80 text-xs leading-6">
              {mode === "register"
                ? `أنشئ حسابك مجاناً واحصل على ${FREE_MESSAGES_LIMIT} رسالة محادثة`
                : adminMode
                  ? "منطقة مخصصة لمشرفي الموقع فقط"
                  : "أهلاً بعودتك إلى Islamic GPT"}
            </p>
          </div>
        </div>

        <CardContent className="p-6">
          <form onSubmit={submit} className="space-y-4">
            {mode === "register" && (
              <div className="space-y-1.5">
                <Label htmlFor="auth-name">الاسم</Label>
                <div className="relative">
                  <User className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    id="auth-name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="اسمك الكامل"
                    className="pr-10 rounded-xl"
                    required
                    minLength={2}
                  />
                </div>
              </div>
            )}

            <div className="space-y-1.5">
              <Label htmlFor="auth-email">البريد الإلكتروني</Label>
              <div className="relative">
                <Mail className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  id="auth-email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  dir="ltr"
                  className="pr-10 rounded-xl text-right"
                  required
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="auth-pass">كلمة المرور</Label>
              <div className="relative">
                <KeyRound className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  id="auth-pass"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="٨ أحرف على الأقل مع رقم"
                  dir="ltr"
                  className="pr-10 rounded-xl text-right"
                  required
                  minLength={8}
                />
              </div>
            </div>

            <Button
              type="submit"
              disabled={busy}
              className={`w-full rounded-full h-11 gap-2 ${
                adminMode && mode === "login"
                  ? "bg-gold text-islamic-900 hover:bg-gold-soft"
                  : "bg-islamic-800 hover:bg-islamic-700"
              }`}
            >
              {busy ? (
                <span className="w-5 h-5 border-2 border-white/40 border-t-white rounded-full animate-spin" />
              ) : mode === "login" ? (
                <>
                  {adminMode ? (
                    <ShieldCheck className="w-4 h-4" />
                  ) : (
                    <LogIn className="w-4 h-4" />
                  )}
                  {adminMode ? "دخول الإدارة" : "دخول"}
                </>
              ) : (
                <>
                  <UserPlus className="w-4 h-4" />
                  إنشاء الحساب
                </>
              )}
            </Button>
          </form>

          <div className="mt-5 text-center text-sm">
            {mode === "login" ? (
              <p className="text-muted-foreground">
                ليس لديك حساب؟{" "}
                <button
                  onClick={() => navigate("/login/register")}
                  className="font-bold text-islamic-700 hover:underline"
                >
                  أنشئ حساباً جديداً
                </button>
              </p>
            ) : (
              <p className="text-muted-foreground">
                لديك حساب بالفعل؟{" "}
                <button
                  onClick={() => navigate("/login")}
                  className="font-bold text-islamic-700 hover:underline"
                >
                  سجّل الدخول
                </button>
              </p>
            )}
          </div>

          {/* دخول الإدارة */}
          {mode === "login" && (
            <div className="mt-6">
              {adminMode ? (
                <button
                  type="button"
                  onClick={() => setAdminMode(false)}
                  className="w-full rounded-2xl border border-border bg-secondary/60 p-4 text-sm font-bold text-islamic-800 flex items-center justify-center gap-2 hover:bg-secondary transition-colors"
                >
                  <ArrowRight className="w-4 h-4" />
                  العودة إلى دخول الأعضاء
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => setAdminMode(true)}
                  aria-pressed={adminMode}
                  className="w-full rounded-2xl border border-gold/50 bg-gold/10 p-4 text-sm font-extrabold text-islamic-900 flex items-center justify-center gap-2 hover:bg-gold/20 transition-colors"
                >
                  <ShieldCheck className="w-4 h-4 text-gold" />
                  تسجيل دخول الإدارة
                </button>
              )}
              {!adminMode && (
                <p className="text-center text-[11px] text-muted-foreground mt-2">
                  هذه المنطقة مخصصة لمشرفي الموقع فقط
                </p>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
