// تعريف الباقات — مشترك بين الواجهة والـ backend

export type PlanId = "WORDS_500" | "WORDS_1500";

export type Plan = {
  id: PlanId;
  name: string;
  priceEgp: number;
  words: number;
  features: string[];
  highlight?: boolean;
};

export const FREE_MESSAGES_LIMIT = 50;

export const PLANS: Plan[] = [
  {
    id: "WORDS_500",
    name: "الباقة الأساسية",
    priceEgp: 50,
    words: 500,
    features: [
      "٥٠٠ كلمة للمحادثة",
      "بحث في آيات القرآن مع ذكر المصدر",
      "سجل محادثات محفوظ",
      "تفعيل فوري بعد الموافقة",
    ],
  },
  {
    id: "WORDS_1500",
    name: "الباقة المميزة",
    priceEgp: 100,
    words: 1500,
    features: [
      "١٥٠٠ كلمة للمحادثة",
      "بحث في آيات القرآن مع ذكر المصدر",
      "سجل محادثات محفوظ",
      "أولوية في المراجعة",
      "تفعيل فوري بعد الموافقة",
    ],
    highlight: true,
  },
];

export function getPlan(id: string): Plan | undefined {
  return PLANS.find((p) => p.id === id);
}

export type PaymentMethodId =
  | "vodafone_cash"
  | "etisalat_cash"
  | "orange_cash"
  | "instapay"
  | "bank";

export const PAYMENT_METHODS: { id: PaymentMethodId; label: string }[] = [
  { id: "vodafone_cash", label: "فودافون كاش" },
  { id: "etisalat_cash", label: "اتصالات كاش" },
  { id: "orange_cash", label: "أورنج كاش" },
  { id: "instapay", label: "إنستاباي" },
  { id: "bank", label: "تحويل بنكي / محفظة" },
];

export function paymentLabel(id: string): string {
  return PAYMENT_METHODS.find((m) => m.id === id)?.label ?? id;
}

// نصوص الرصيد
export function balanceText(user: {
  plan: string;
  wordBalance: number;
  freeMessagesUsed: number;
}): string {
  if (user.plan === "FREE") {
    const remaining = Math.max(0, FREE_MESSAGES_LIMIT - user.freeMessagesUsed);
    return `${remaining} رسالة متبقية من ${FREE_MESSAGES_LIMIT}`;
  }
  return `${user.wordBalance} كلمة متبقية`;
}
