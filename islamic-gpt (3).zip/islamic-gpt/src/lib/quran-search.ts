import { db } from "@/lib/db";

// ---------- تطبيع النص العربي للبحث ----------
export function normalizeArabic(text: string): string {
  return text
    // إزالة التشكيل وعلامات الوقف
    .replace(/[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED\u08D3-\u08FF\u08F0-\u08F3]/g, "")
    // توحيد الألف
    .replace(/[\u0622\u0623\u0625\u0671\u0672\u0673]/g, "\u0627")
    // توحيد الياء والألف المقصورة
    .replace(/[\u0649\u064A]/g, "\u064A")
    // التاء المربوطة -> هاء
    .replace(/\u0629/g, "\u0647")
    // الهمزة على السطر
    .replace(/\u0621/g, "")
    // إزالة التطويل والمسافات الزائدة
    .replace(/\u0640/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

type AyahRow = { surahNumber: number; numberInSurah: number; text: string; norm: string };

let cache: AyahRow[] | null = null;
let cacheTime = 0;
const CACHE_TTL = 24 * 60 * 60 * 1000;

async function loadAyahs(): Promise<AyahRow[]> {
  if (cache && Date.now() - cacheTime < CACHE_TTL) return cache;
  const rows = await db.ayah.findMany({
    select: { surahNumber: true, numberInSurah: true, text: true },
    orderBy: [{ surahNumber: "asc" }, { numberInSurah: "asc" }],
  });
  cache = rows.map((r) => ({
    ...r,
    norm: normalizeArabic(r.text),
  }));
  cacheTime = Date.now();
  return cache;
}

export type SearchHit = {
  surah: number;
  surahName: string;
  ayah: number;
  text: string;
};

const STOP_WORDS = new Set([
  "من","في","عن","على","الي","الى","ما","هو","هي","هل","كيف","متى","اين","اذا","اذا",
  "و","ف","ب","ل","ان","انه","انها","هذا","هذه","ذلك","تلك","الذي","التي","يا","كل",
  "يجب","يكون","تكون","كان","كانت","عند","لدى","بين","مع","حتى","لم","لا","بن","به",
]);

export function extractKeywords(question: string): string[] {
  const words = normalizeArabic(question)
    .split(/[^\u0621-\u064A]+/)
    .filter((w) => w.length >= 3 && !STOP_WORDS.has(w));
  return Array.from(new Set(words)).slice(0, 8);
}

/**
 * بحث حقيقي في آيات القرآن داخل قاعدة البيانات.
 * يرتب النتائج بعدد الكلمات المطابقة ثم أولوية الآيات القصيرة الشهيرة.
 */
export async function searchQuran(question: string, maxHits = 6): Promise<SearchHit[]> {
  const rows = await loadAyahs();
  const keywords = extractKeywords(question);
  if (keywords.length === 0) return [];

  const scored: { row: AyahRow; score: number }[] = [];
  for (const row of rows) {
    let score = 0;
    for (const kw of keywords) {
      if (row.norm.includes(kw)) score += 1;
    }
    if (score > 0) scored.push({ row, score });
  }

  scored.sort((a, b) => {
    if (b.score !== a.score) return b.score - a.score;
    return a.row.text.length - b.row.text.length;
  });

  // تنويع السور: آية واحدة كحد أقصى من كل سورة في أعلى النتائج
  const seenSurahs = new Set<number>();
  const hits: SearchHit[] = [];
  const surahNames = await getSurahNames();
  for (const { row } of scored) {
    if (seenSurahs.has(row.surahNumber)) continue;
    seenSurahs.add(row.surahNumber);
    hits.push({
      surah: row.surahNumber,
      surahName: surahNames[row.surahNumber] ?? "",
      ayah: row.numberInSurah,
      text: row.text,
    });
    if (hits.length >= maxHits) break;
  }
  return hits;
}

let surahNamesCache: Record<number, string> | null = null;
async function getSurahNames(): Promise<Record<number, string>> {
  if (surahNamesCache) return surahNamesCache;
  const surahs = await db.surah.findMany({ select: { number: true, name: true } });
  surahNamesCache = Object.fromEntries(surahs.map((s) => [s.number, s.name]));
  return surahNamesCache;
}
