"use client";

import { create } from "zustand";
import recitersJson from "@/data/reciters.json";

// ---------- الأنواع ----------

export type SafeUser = {
  id: string;
  email: string;
  name: string;
  role: string;
  plan: string;
  wordBalance: number;
  freeMessagesUsed: number;
};

export type Reciter = {
  id: number;
  name: string;
  moshaf: string;
  server: string;
};

export const RECITERS: Reciter[] = recitersJson as Reciter[];

// ---------- التوجيه (hash router) ----------

export type Route =
  | { view: "home" }
  | { view: "quran" }
  | { view: "surah"; n: number }
  | { view: "chat" }
  | { view: "plans" }
  | { view: "account" }
  | { view: "admin" }
  | { view: "about" }
  | { view: "login"; mode: "login" | "register" };

export function parseHash(hash: string): Route {
  const h = (hash || "").replace(/^#\/?/, "");
  const parts = h.split("/").filter(Boolean);
  if (parts.length === 0) return { view: "home" };
  switch (parts[0]) {
    case "quran":
      return { view: "quran" };
    case "surah": {
      const n = parseInt(parts[1] || "1", 10);
      return { view: "surah", n: Math.min(114, Math.max(1, isNaN(n) ? 1 : n)) };
    }
    case "chat":
      return { view: "chat" };
    case "plans":
      return { view: "plans" };
    case "account":
      return { view: "account" };
    case "admin":
      return { view: "admin" };
    case "about":
      return { view: "about" };
    case "login":
      return { view: "login", mode: parts[1] === "register" ? "register" : "login" };
    case "register":
      return { view: "login", mode: "register" };
    default:
      return { view: "home" };
  }
}

export function navigate(path: string) {
  if (typeof window === "undefined") return;
  const target = path.startsWith("#") ? path : `#${path}`;
  if (window.location.hash === target) {
    window.dispatchEvent(new HashChangeEvent("hashchange"));
  } else {
    window.location.hash = target;
  }
}

// ---------- المشغل الصوتي ----------

let audioEl: HTMLAudioElement | null = null;
function getAudio(): HTMLAudioElement | null {
  if (typeof window === "undefined") return null;
  if (!audioEl) {
    audioEl = new Audio();
    audioEl.preload = "auto";
  }
  return audioEl;
}

function surahFileName(n: number): string {
  return `${String(n).padStart(3, "0")}.mp3`;
}

export type PlayerState = {
  reciterId: number;
  surah: number;
  surahName: string;
  url: string;
  playing: boolean;
  currentTime: number;
  duration: number;
  speed: number;
  loading: boolean;
};

type Store = {
  route: Route;
  user: SafeUser | null;
  authLoading: boolean;
  player: PlayerState;
  unreadNotice: string | null;

  setRoute: (r: Route) => void;
  setUser: (u: SafeUser | null) => void;
  setAuthLoading: (b: boolean) => void;
  refreshMe: () => Promise<void>;
  logout: () => Promise<void>;

  playSurah: (
    surah: number,
    surahName: string,
    opts?: { autoPlay?: boolean; startTime?: number }
  ) => Promise<void>;
  setReciter: (id: number) => Promise<void>;
  togglePlay: () => void;
  seek: (t: number) => void;
  setSpeed: (s: number) => void;
  playAdjacent: (dir: 1 | -1) => Promise<void>;
  updateFromAudio: (patch: Partial<PlayerState>) => void;
  persistPosition: () => void;
};

const DEFAULT_SPEED = 1;

function savedPrefs(): { reciterId: number; lastSurah: number } {
  if (typeof window === "undefined") return { reciterId: RECITERS[0]?.id ?? 1, lastSurah: 1 };
  try {
    const rec = parseInt(localStorage.getItem("ig_reciter") || "", 10);
    const last = parseInt(localStorage.getItem("ig_last_surah") || "", 10);
    return {
      reciterId: RECITERS.some((r) => r.id === rec) ? rec : RECITERS[0]?.id ?? 1,
      lastSurah: isNaN(last) ? 1 : Math.min(114, Math.max(1, last)),
    };
  } catch {
    return { reciterId: RECITERS[0]?.id ?? 1, lastSurah: 1 };
  }
}

export const useStore = create<Store>((set, get) => ({
  route: { view: "home" },
  user: null,
  authLoading: true,
  unreadNotice: null,
  player: {
    reciterId: 1,
    surah: 1,
    surahName: "",
    url: "",
    playing: false,
    currentTime: 0,
    duration: 0,
    speed: DEFAULT_SPEED,
    loading: false,
  },

  setRoute: (r) => set({ route: r }),
  setUser: (u) => set({ user: u }),
  setAuthLoading: (b) => set({ authLoading: b }),

  refreshMe: async () => {
    try {
      const res = await fetch("/api/auth/me", { cache: "no-store" });
      const data = await res.json();
      set({ user: data.user ?? null, authLoading: false });
    } catch {
      set({ user: null, authLoading: false });
    }
  },

  logout: async () => {
    try {
      await fetch("/api/auth/logout", { method: "POST" });
    } catch {}
    set({ user: null });
    navigate("/");
  },

  playSurah: async (surah, surahName, opts = {}) => {
    const audio = getAudio();
    if (!audio) return;
    const state = get();
    const prefs = savedPrefs();
    const reciterId =
      state.player.reciterId && state.player.url ? state.player.reciterId : prefs.reciterId;
    const reciter = RECITERS.find((r) => r.id === reciterId) ?? RECITERS[0];
    if (!reciter) return;
    const url = `${reciter.server}/${surahFileName(surah)}`;

    set((s) => ({
      player: {
        ...s.player,
        loading: true,
        surah,
        surahName,
        url,
        reciterId: reciter.id,
        currentTime: 0,
        duration: 0,
      },
    }));
    localStorage.setItem("ig_last_surah", String(surah));
    localStorage.setItem("ig_reciter", String(reciter.id));

    audio.src = url;
    audio.playbackRate = state.player.speed;
    if (opts.startTime && opts.startTime > 5) {
      audio.currentTime = opts.startTime;
    }
    if (opts.autoPlay !== false) {
      try {
        await audio.play();
        set((s) => ({ player: { ...s.player, playing: true, loading: false } }));
      } catch {
        set((s) => ({ player: { ...s.player, playing: false, loading: false } }));
      }
    } else {
      set((s) => ({ player: { ...s.player, loading: false, playing: false } }));
    }

    // حفظ موضع القراءة للمستخدم المسجل
    fetch("/api/quran/progress", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ surah, ayah: 1, audioTime: opts.startTime ?? 0 }),
    }).catch(() => {});
  },

  setReciter: async (id) => {
    const audio = getAudio();
    if (!audio) return;
    const reciter = RECITERS.find((r) => r.id === id);
    if (!reciter) return;
    localStorage.setItem("ig_reciter", String(id));
    const { player } = get();
    const wasPlaying = player.playing;
    const startAt = player.currentTime;
    set((s) => ({ player: { ...s.player, reciterId: id, loading: true } }));
    if (player.url) {
      audio.src = `${reciter.server}/${surahFileName(player.surah)}`;
      audio.currentTime = startAt;
      audio.playbackRate = player.speed;
      if (wasPlaying) {
        try {
          await audio.play();
          set((s) => ({ player: { ...s.player, playing: true, loading: false } }));
        } catch {
          set((s) => ({ player: { ...s.player, playing: false, loading: false } }));
        }
      } else {
        set((s) => ({ player: { ...s.player, loading: false } }));
      }
    } else {
      set((s) => ({ player: { ...s.player, loading: false } }));
    }
  },

  togglePlay: () => {
    const audio = getAudio();
    if (!audio || !get().player.url) return;
    if (audio.paused) {
      audio.play().catch(() => {});
      set((s) => ({ player: { ...s.player, playing: true } }));
    } else {
      audio.pause();
      get().persistPosition();
      set((s) => ({ player: { ...s.player, playing: false } }));
    }
  },

  seek: (t) => {
    const audio = getAudio();
    if (!audio) return;
    audio.currentTime = t;
    set((s) => ({ player: { ...s.player, currentTime: t } }));
  },

  setSpeed: (s) => {
    const audio = getAudio();
    if (audio) audio.playbackRate = s;
    set((st) => ({ player: { ...st.player, speed: s } }));
  },

  playAdjacent: async (dir) => {
    const { player } = get();
    const next = Math.min(114, Math.max(1, player.surah + dir));
    if (next === player.surah) return;
    await get().playSurah(next, "", { autoPlay: true });
  },

  updateFromAudio: (patch) => set((s) => ({ player: { ...s.player, ...patch } })),

  persistPosition: () => {
    const { player, user } = get();
    if (!player.url) return;
    try {
      localStorage.setItem(`ig_pos_${player.surah}`, String(Math.floor(player.currentTime)));
      localStorage.setItem("ig_last_surah", String(player.surah));
    } catch {}
    if (user) {
      fetch("/api/quran/progress", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          surah: player.surah,
          ayah: 1,
          audioTime: Math.floor(player.currentTime),
        }),
      }).catch(() => {});
    }
  },
}));

export function getAudioElement(): HTMLAudioElement | null {
  return getAudio();
}
