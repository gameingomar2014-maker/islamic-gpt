import { createHmac, randomBytes, scryptSync, timingSafeEqual } from "crypto";
import { cookies } from "next/headers";
import { db } from "@/lib/db";

const AUTH_SECRET =
  process.env.AUTH_SECRET || "islamic-gpt-dev-secret-change-in-production";

export const SESSION_COOKIE = "ig_session";
const SESSION_DAYS = 30;

// ---------- كلمات المرور (scrypt) ----------

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `s2$${salt}$${hash}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  try {
    const [scheme, salt, hash] = stored.split("$");
    if (scheme !== "s2" || !salt || !hash) return false;
    const candidate = scryptSync(password, salt, 64);
    const expected = Buffer.from(hash, "hex");
    return candidate.length === expected.length && timingSafeEqual(candidate, expected);
  } catch {
    return false;
  }
}

// ---------- الجلسات (توكن موقّع HMAC) ----------

function b64url(input: string | Buffer): string {
  return Buffer.from(input).toString("base64url");
}

function sign(payload: string): string {
  return createHmac("sha256", AUTH_SECRET).update(payload).digest("base64url");
}

export function createSessionToken(userId: string): string {
  const payload = b64url(
    JSON.stringify({
      uid: userId,
      exp: Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000,
    })
  );
  return `${payload}.${sign(payload)}`;
}

export function verifySessionToken(token: string): string | null {
  try {
    const [payload, sig] = token.split(".");
    if (!payload || !sig) return null;
    const expected = sign(payload);
    const a = Buffer.from(sig);
    const b = Buffer.from(expected);
    if (a.length !== b.length || !timingSafeEqual(a, b)) return null;
    const data = JSON.parse(Buffer.from(payload, "base64url").toString()) as {
      uid: string;
      exp: number;
    };
    if (!data.uid || !data.exp || data.exp < Date.now()) return null;
    return data.uid;
  } catch {
    return null;
  }
}

// ---------- المستخدم الحالي ----------

export type SafeUser = {
  id: string;
  email: string;
  name: string;
  role: string;
  plan: string;
  wordBalance: number;
  freeMessagesUsed: number;
};

export function toSafeUser(u: {
  id: string;
  email: string;
  name: string;
  role: string;
  plan: string;
  wordBalance: number;
  freeMessagesUsed: number;
}): SafeUser {
  return {
    id: u.id,
    email: u.email,
    name: u.name,
    role: u.role,
    plan: u.plan,
    wordBalance: u.wordBalance,
    freeMessagesUsed: u.freeMessagesUsed,
  };
}

export async function getCurrentUser(): Promise<SafeUser | null> {
  try {
    const store = await cookies();
    const token = store.get(SESSION_COOKIE)?.value;
    if (!token) return null;
    const uid = verifySessionToken(token);
    if (!uid) return null;
    const user = await db.user.findUnique({ where: { id: uid } });
    if (!user) return null;
    return toSafeUser(user);
  } catch {
    return null;
  }
}

export async function requireUser(): Promise<SafeUser | null> {
  return getCurrentUser();
}

export async function requireAdmin(): Promise<SafeUser | null> {
  const user = await getCurrentUser();
  if (!user || user.role !== "ADMIN") return null;
  return user;
}

export function sessionCookieOptions() {
  return {
    httpOnly: true,
    sameSite: "lax" as const,
    secure: process.env.NODE_ENV === "production",
    maxAge: SESSION_DAYS * 24 * 60 * 60,
    path: "/",
  };
}
