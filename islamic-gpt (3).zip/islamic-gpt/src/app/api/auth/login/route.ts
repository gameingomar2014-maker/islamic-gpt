import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import {
  verifyPassword,
  createSessionToken,
  SESSION_COOKIE,
  sessionCookieOptions,
  toSafeUser,
} from "@/lib/auth";
import { rateLimit, getClientIp } from "@/lib/rate-limit";
import { resetRateLimit } from "@/lib/rate-limit";

const schema = z.object({
  email: z.string().trim().email().max(120),
  password: z.string().min(1).max(100),
});

export async function POST(req: Request) {
  const ip = getClientIp(req);

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "بيانات غير صالحة" }, { status: 400 });
  }

  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "بريد أو كلمة مرور غير صالحة" }, { status: 400 });
  }

  const { email, password } = parsed.data;
  const normalizedEmail = email.toLowerCase();

  // حماية من محاولات الدخول المتكررة: ٥ محاولات كل ١٥ دقيقة لكل (IP + بريد)
  const rl = rateLimit(`login:${ip}:${normalizedEmail}`, 5, 15 * 60 * 1000);
  if (!rl.allowed) {
    return NextResponse.json(
      {
        error: `تم تجاوز عدد المحاولات المسموح. حاول مرة أخرى بعد ${Math.ceil(
          rl.retryAfterSec / 60
        )} دقيقة`,
      },
      { status: 429 }
    );
  }

  const user = await db.user.findUnique({ where: { email: normalizedEmail } });
  if (!user || !verifyPassword(password, user.passwordHash)) {
    return NextResponse.json(
      { error: "البريد الإلكتروني أو كلمة المرور غير صحيحة" },
      { status: 401 }
    );
  }

  const res = NextResponse.json({ user: toSafeUser(user) });
  // نجاح الدخول يصفّر عدّاد المحاولات الفاشلة
  resetRateLimit(`login:${ip}:${normalizedEmail}`);
  res.cookies.set(SESSION_COOKIE, createSessionToken(user.id), sessionCookieOptions());
  return res;
}
