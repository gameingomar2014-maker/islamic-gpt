import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";
import { FREE_MESSAGES_LIMIT } from "@/lib/plans";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ user: null });
  return NextResponse.json({
    user,
    balance: {
      freeRemaining: Math.max(0, FREE_MESSAGES_LIMIT - user.freeMessagesUsed),
      plan: user.plan,
      wordBalance: user.wordBalance,
    },
  });
}
