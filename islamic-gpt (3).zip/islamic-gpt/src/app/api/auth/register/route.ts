import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { hashPassword, createSessionToken, SESSION_COOKIE, sessionCookieOptions, toSafeUser } from "@/lib/auth";
import { rateLimit, getClientIp } from "@/lib/rate-limit";

const schema = z.object({
  name: z.string().trim().min(2, "الاسم قصير جداً").max(60),
  email: z.string().trim().email("بريد إلكتروني غير صالح").max(120),
  password: z
    .string()
    .min(8, "كلمة المرور ٨ أحرف على الأقل")
    .max(100)
    .regex(/[A-Za-z\u0600-\u06FF]/, "كلمة المرور يجب أن تحتوي على حرف")
    .regex(/[0-9]/, "كلمة المرور يجب أن تحتوي على رقم"),
});

export async function POST(req: Request) {
  const ip = getClientIp(req);
  const rl = rateLimit(`register:${ip}`, 10, 60 * 60 * 1000);
  if (!rl.allowed) {
    return NextResponse.json(
      { error: `محاولات كثيرة، حاول بعد ${rl.retryAfterSec} ثانية` },
      { status: 429 }
    );
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "بيانات غير صالحة" }, { status: 400 });
  }

  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message ?? "بيانات غير صالحة" },
      { status: 400 }
    );
  }

  const { name, email, password } = parsed.data;
  const normalizedEmail = email.toLowerCase();

  const existing = await db.user.findUnique({ where: { email: normalizedEmail } });
  if (existing) {
    return NextResponse.json(
      { error: "هذا البريد مسجل بالفعل، سجّل الدخول بدلاً من ذلك" },
      { status: 409 }
    );
  }

  const user = await db.user.create({
    data: {
      name,
      email: normalizedEmail,
      passwordHash: hashPassword(password),
      role: "USER",
      plan: "FREE",
    },
  });

  const res = NextResponse.json({ user: toSafeUser(user) }, { status: 201 });
  res.cookies.set(SESSION_COOKIE, createSessionToken(user.id), sessionCookieOptions());
  return res;
}
