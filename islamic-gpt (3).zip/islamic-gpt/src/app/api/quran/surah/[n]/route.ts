import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ n: string }> }
) {
  const { n } = await params;
  const num = parseInt(n, 10);
  if (isNaN(num) || num < 1 || num > 114) {
    return NextResponse.json({ error: "رقم سورة غير صالح" }, { status: 400 });
  }

  const surah = await db.surah.findUnique({
    where: { number: num },
    include: {
      ayahs: {
        select: { numberInSurah: true, text: true },
        orderBy: { numberInSurah: "asc" },
      },
    },
  });
  if (!surah) {
    return NextResponse.json({ error: "السورة غير موجودة" }, { status: 404 });
  }

  return NextResponse.json({
    surah: {
      number: surah.number,
      name: surah.name,
      englishName: surah.englishName,
      revelationType: surah.revelationType,
      numberOfAyahs: surah.numberOfAyahs,
      // البسملة تُعرض كسطر مستقل لكل السور ما عدا التوبة (٩)،
      // أما الفاتحة (١) فالبسملة فيها آية أولى بحد ذاتها
      showBismillah: surah.number !== 9 && surah.number !== 1,
      ayahs: surah.ayahs,
    },
  });
}
