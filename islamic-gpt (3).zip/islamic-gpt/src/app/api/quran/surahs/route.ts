import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  const surahs = await db.surah.findMany({
    select: {
      number: true,
      name: true,
      englishName: true,
      revelationType: true,
      numberOfAyahs: true,
    },
    orderBy: { number: "asc" },
  });
  return NextResponse.json({ surahs });
}
