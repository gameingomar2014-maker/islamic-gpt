import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/auth";
import { getPlan } from "@/lib/plans";

const schema = z.object({
  action: z.enum(["approve", "reject"]),
  adminNote: z.string().trim().max(300).nullish(),
});

// موافقة أو رفض طلب اشتراك
export async function POST(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ error: "غير مصرح" }, { status: 403 });

  const { id } = await params;
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "بيانات غير صالحة" }, { status: 400 });
  }
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "بيانات غير صالحة" }, { status: 400 });
  }

  const request = await db.subscriptionRequest.findUnique({ where: { id } });
  if (!request) {
    return NextResponse.json({ error: "الطلب غير موجود" }, { status: 404 });
  }
  if (request.status !== "PENDING") {
    return NextResponse.json(
      { error: "تمت مراجعة هذا الطلب مسبقاً" },
      { status: 409 }
    );
  }

  const plan = getPlan(request.planId);
  if (!plan) return NextResponse.json({ error: "باقة غير معروفة" }, { status: 400 });

  if (parsed.data.action === "approve") {
    // تفعيل فوري: تحديث حالة الطلب + إضافة الرصيد للمستخدم
    await db.$transaction([
      db.subscriptionRequest.update({
        where: { id },
        data: {
          status: "APPROVED",
          reviewedAt: new Date(),
          adminNote: parsed.data.adminNote ?? "تم التحقق من الدفع",
        },
      }),
      db.subscription.create({
        data: {
          userId: request.userId,
          planId: plan.id,
          wordsGranted: plan.words,
          requestId: request.id,
        },
      }),
      db.user.update({
        where: { id: request.userId },
        data: {
          plan: plan.id,
          wordBalance: { increment: plan.words },
        },
      }),
    ]);
    return NextResponse.json({
      ok: true,
      message: `تم تفعيل الاشتراك وإضافة ${plan.words} كلمة لحساب المستخدم`,
    });
  }

  await db.subscriptionRequest.update({
    where: { id },
    data: {
      status: "REJECTED",
      reviewedAt: new Date(),
      adminNote: parsed.data.adminNote ?? "لم يتم التحقق من عملية الدفع",
    },
  });
  return NextResponse.json({ ok: true, message: "تم رفض الطلب" });
}
