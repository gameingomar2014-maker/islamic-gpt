import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/auth";

export async function GET() {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ error: "غير مصرح" }, { status: 403 });

  const requests = await db.subscriptionRequest.findMany({
    select: {
      id: true,
      planId: true,
      userName: true,
      phone: true,
      paymentMethod: true,
      transactionRef: true,
      status: true,
      amount: true,
      words: true,
      adminNote: true,
      createdAt: true,
      reviewedAt: true,
      userId: true,
      user: { select: { email: true } },
    },
    orderBy: [{ status: "asc" }, { createdAt: "desc" }],
    take: 200,
  });

  const withReceipt = await db.subscriptionRequest.findMany({
    where: { receiptImage: { not: null } },
    select: { id: true },
  });
  const receiptIds = new Set(withReceipt.map((r) => r.id));

  return NextResponse.json({
    requests: requests.map((r) => ({ ...r, hasReceipt: receiptIds.has(r.id) })),
  });
}
