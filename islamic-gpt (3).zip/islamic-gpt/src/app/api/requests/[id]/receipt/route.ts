import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";

// عرض صورة الإيصال — للمالك أو للأدمن فقط
export async function GET(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  const { id } = await params;

  const request = await db.subscriptionRequest.findUnique({
    where: { id },
    select: { receiptImage: true, userId: true },
  });
  if (!request || !request.receiptImage) {
    return NextResponse.json({ error: "لا يوجد إيصال" }, { status: 404 });
  }
  if (user.role !== "ADMIN" && user.id !== request.userId) {
    return NextResponse.json({ error: "غير مصرح" }, { status: 403 });
  }

  return NextResponse.json({ receiptImage: request.receiptImage });
}
